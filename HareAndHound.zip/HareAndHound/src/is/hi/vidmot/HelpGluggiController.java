/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package is.hi.vidmot;

import java.awt.Toolkit;
import java.io.FileInputStream; 
import java.io.FileNotFoundException; 
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Notandi
 */
public class HelpGluggiController implements Initializable {
    
    
    @FXML
    private AnchorPane HelpGluggi;
    @FXML
    private Label label;
    @FXML
    private Button preButton;
    @FXML
    private Button nextButton;
    @FXML
    private Button okButton;
    @FXML
    private ImageView ivy;
    
    
    
    private final Image [] ikonar = new Image[6]; 
    private final String [] MYNDIR = new String []{"b","c","d","e","f","g"};
    private int tala = 0;

//    private FXMLDocumentController fdcontroller;
//
//    public void initHelpGluggi(FXMLDocumentController f) {
//        fdcontroller = f;
//    }
//    
//    

    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        setjaPict();
//        for (int i = 0; i < 6; i++) {            
//            ikonar[i] = new Image("file:..\\..\\..\\meiraMyndir\\"+ (MYNDIR[i]+".png"));
//            ivy = new ImageView(ikonar[i]);
//            ivy.setFitWidth(label.getWidth());
//            ivy.setFitHeight(label.getHeight());
//            label.setGraphic(ivy);
//        }
//        ikonar[0] = new Image("file:..\\..\\..\\meiraMyndir\\a.png");
//        ivy = new ImageView(ikonar[0]);
//        ivy.setFitWidth(label.getWidth());
//        ivy.setFitHeight(label.getHeight());
//        label.setGraphic(ivy);
    }    
    
    private void setjaPict(){
        ikonar[0] = new Image("file:..\\..\\..\\meiraMyndir\\b.png");
        ikonar[1] = new Image("file:..\\..\\..\\meiraMyndir\\c.png");
        ikonar[2] = new Image("file:..\\..\\..\\meiraMyndir\\d.png");
        ikonar[3] = new Image("file:..\\..\\..\\meiraMyndir\\e.png");
        ikonar[4] = new Image("file:..\\..\\..\\meiraMyndir\\f.png");
        ikonar[5] = new Image("file:..\\..\\..\\meiraMyndir\\g.png");
    }

    @FXML
    private void preACTION(ActionEvent event) {
        preButton.setOnMouseClicked(mousePressedPrevious);
    }

    @FXML
    private void nextACTION(ActionEvent event) {
        nextButton.setOnMouseClicked(mousePressedNext);
    }

    @FXML
    private void doneACTION(ActionEvent event) throws IOException {
        Parent p = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        Scene s = new Scene(p);
        Stage app = (Stage)((Node) event.getSource()).getScene().getWindow();
        app.setScene(s);
        app.show();
    }
    
    
    @FXML
    private void qAction(ActionEvent event) {
        Platform.exit();
        System.exit(0);
    }
    
    
    
    
    
    
    /**
     * Atburðahandler fyrir músið
     */
    private final EventHandler<MouseEvent> mousePressedNext =
            new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    if(tala == 6) {
                        if(preButton.isDisabled() && okButton.isDisabled()) {
                            preButton.setDisable(false);
                            okButton.setDisable(false);
                        }
                    }
                    if(tala == 6) {
                        tala = 0;
                    }
                    else tala = tala + 1;
                    ivy = new ImageView(ikonar[tala]);
                    ivy.setFitWidth(label.getWidth());
                    ivy.setFitHeight(label.getHeight());
                    label.setGraphic(ivy);
                    
                }
                
            };

    /**
     * Atburðahandler fyrir músið
     */
    private final EventHandler<MouseEvent> mousePressedPrevious =
            new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) { 
                    if(tala == 0) {
                        tala = 6;
                    }
                    else tala = tala - 1;
                    ivy = new ImageView(ikonar[tala]);
                    ivy.setFitWidth(label.getWidth());
                    ivy.setFitHeight(label.getHeight());
                    label.setGraphic(ivy);
                }
                
            };

    @FXML
    private void proAction(ActionEvent event) throws IOException {
        Parent p = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        Scene s = new Scene(p);
        Stage app = (Stage)((Node) event.getSource()).getScene().getWindow();
        app.setScene(s);
        app.show();
    }



}
