/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package is.hi.vidmot;

import is.hi.vinnsla.algoRithm;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.RadioButton;
import javafx.scene.layout.Pane;

/**
 *
 * @author Notandi
 */
public class teiknaGrunnbord extends Pane{
    
    private FXMLDocumentController fdcontroller;

    public void setFdcontroller(FXMLDocumentController fdc) {
        fdcontroller = fdc;
    }
    
    
//    RadioButton hsB = fdcontroller.getHoundsButton();
//    RadioButton hareB = fdcontroller.getHareButton();
    
    private final Reitur[][] reitur = new Reitur[3][5];
    private final Reitur[] rData = new Reitur[11];
    
    private algoRithm al = new algoRithm();
    
    private static final String UTANBORD = "Peð er utan spilaborðið";
    private static final String PEDABORDI = "Peð er þegar á borði";
    
    int oldX = 0;
    int oldY = 0;
    
    
    
    public teiknaGrunnbord() {
        stillaPane();
    }
    
    /**
     * Teiknar grunnborð Hare and Hounds á graphics context gc
     * @param gc 
     */
    public void stillaSpilaBord(GraphicsContext gc) {
//        printNew();


        // Byrja að teikna alla línur á borðið
        gc.strokeLine(80, 240, 240, 120);
        gc.strokeLine(80, 240, 240, 240);
        gc.strokeLine(80, 240, 240, 360);
        gc.strokeLine(240, 240, 240, 120);
        gc.strokeLine(240, 240, 240, 360);
        
        gc.strokeLine(400, 120, 240, 120);
        gc.strokeLine(400, 240, 400, 120);
        gc.strokeLine(400, 240, 240, 120);
        gc.strokeLine(400, 240, 240, 240);
        gc.strokeLine(400, 240, 240, 360);
        gc.strokeLine(400, 240, 400, 360);
        gc.strokeLine(400, 360, 240, 360);
        
        gc.strokeLine(560, 120, 400, 120);
        gc.strokeLine(560, 120, 400, 240);
        gc.strokeLine(560, 120, 560, 240);
        gc.strokeLine(560, 240, 400, 240);
        gc.strokeLine(560, 360, 560, 240);
        gc.strokeLine(560, 360, 400, 240);
        gc.strokeLine(560, 360, 400, 360);
        
        gc.strokeLine(560, 360, 720, 240);
        gc.strokeLine(560, 240, 720, 240);
        gc.strokeLine(560, 120, 720, 240);
        

        // teikna svo hringir
        gc.fillOval(690, 210, 60, 60);
        gc.fillOval(530, 90, 60, 60);
//        gc.fillOval(370, 90, 60, 60);
        gc.fillOval(210, 90, 60, 60);
        gc.fillOval(50, 210, 60, 60);
        gc.fillOval(210, 330, 60, 60);
//        gc.fillOval(370, 330, 60, 60);
        gc.fillOval(530, 330, 60, 60);
//        gc.fillOval(210, 210, 60, 60);
        gc.fillOval(370, 210, 60, 60);
//        gc.fillOval(530, 210, 60, 60);
        
        // prufa teikna ferningar fyrst 
//        gc.fillRect(690, 210, 60, 60);
//        gc.fillRect(530, 90, 60, 60);
        gc.fillRect(370, 90, 60, 60);
//        gc.fillRect(210, 90, 60, 60);
//        gc.fillRect(50, 210, 60, 60);
//        gc.fillRect(210, 330, 60, 60);
        gc.fillRect(370, 330, 60, 60);
//        gc.fillRect(530, 330, 60, 60);
        gc.fillRect(210, 210, 60, 60);
//        gc.fillRect(370, 210, 60, 60);
        gc.fillRect(530, 210, 60, 60);
//
//        gc.fillRect(50, 90, 60, 60);
    }
    
    /**
     * Frumstilla reitina sem afmarka hverja sellu í spilaborð
     */
    public void stillaPane() {
        int x = 50;
        int y = 90;
        for(int i=0; i<3; i++) {
            for(int j=0; j<5; j++) {
                // x er x-Ás, y er y-Ás og 50 stendur fyrir radíus
                reitur[i][j] = new Reitur(x, y, 60, 60);
                // 60 er breidd af ferningur, 100 er svona space á milli 2 ferningar
                x = x+60+100;
            }
            x = 50;
            // fyrsta 60 er fyrir hæð á ferning, hinn 60 er fyrir space milli 2 ferningar
            y = y+60+60;
        }
    }
    
    /**
     * Fallið setjaABord tekur við x-ás og y-ás 
     * og sé um að gera eftirfarandi hlutverk:
     * 
     * 1. Tilkynna villu þegar færa peð í reit
     *    a. ef peð lendir utan reitur þá gefa villu skilaboð
     *    b. ef það er eitthvað peð á borðið þá skila villu skilaboð
     * 2. setja peð á borðið
     * 3. athuga ef einhver vinnur leikinn
     * 4. að lokum endurstilla alla gildið á borðið í 0
     * @param x er x-ás
     * @param y er y-ás
     */
    public void setjaABord(int x, int y) {
//        System.out.println(x + " "  + y);
        System.out.println("Töflu before");
        al.prentaBord();
        int[] r = hvadaReitur(x, y);
//        fdcontroller.tilkynnaVillu("");
        

        if( r[0]==0 && r[1]==0 ) {
            fdcontroller.tilkynnaVillu(UTANBORD);
            return;
        }
        if(al.erThegarABordi(r)) {
            fdcontroller.tilkynnaVillu(PEDABORDI);
            return;
        } else {
            // tékka hvort peð færði um 1 eða meira
            
            al.setjaPedABord(r);
            int theWinnerIs = athVinningur();
            if(theWinnerIs==0) {
                int nuverandiLeikmadur = al.getNuverandiLeikmadur();
                
                if(nuverandiLeikmadur == 1) {
                    
                    // leikmaður 2 eða Hare á að gera
                    al.setNuverandiLeikmadur(2);
                    
//                    if( (fdcontroller.getHoundsButton().isSelected()) && (fdcontroller.getHoundsButton().isDisabled() == false) ) {
                        fdcontroller.getHareButton().setSelected(true);
                        fdcontroller.getHareButton().setDisable(false);
                        fdcontroller.getHoundsButton().setDisable(true);
                        fdcontroller.getHoundsButton().setSelected(false);
                        fdcontroller.tilkynnaVillu("Now Hare its your turn, run, run");
//                    }
//                    if(fdcontroller.getHareButton().isSelected()) {
//                        
//                    }
                    fdcontroller.frestiOgVirkaPed();
                    

                } 
                else if(nuverandiLeikmadur == 2) {
                    
                    al.setNuverandiLeikmadur(1);
                    
//                    if( (fdcontroller.getHareButton().isSelected()) &&  (fdcontroller.getHareButton().isDisabled()==false) ) {
                    fdcontroller.getHoundsButton().setSelected(true);
                    fdcontroller.getHoundsButton().setDisable(false);
                    fdcontroller.getHareButton().setSelected(false);
                    fdcontroller.getHareButton().setDisable(true);
//                        
                    fdcontroller.tilkynnaVillu("Hounds is now on the hunt");
//                    }
                    fdcontroller.frestiOgVirkaPed();
                }
            }
            else if(theWinnerIs==1) {
                winnerHounds();
                al.setNuverandiLeikmadur(1);
            }
            else if(theWinnerIs==2) {
                winnerHare();
                al.setNuverandiLeikmadur(1);
            }
        }
        System.out.println("Töflu after");
        al.prentaBord();
        // endurstilla alla gildi á borðið í 0
//        al.endurStillaGildi();
    }
    
    /**
     * Stilla þegar Hounds vinnur leikinn
     */
    public void winnerHounds() {
        al.frumStillaGildi();
        fdcontroller.displayWinner(1);
        fdcontroller.oVirkjaHnappa(true);
        fdcontroller.getRealPane().setDisable(true);
    }
    
    /**
     * Stilla þegar Hare vinnur leikinn
     */
    public void winnerHare() {
        al.frumStillaGildi();
        fdcontroller.displayWinner(2);
        fdcontroller.oVirkjaHnappa(true);
        fdcontroller.getRealPane().setDisable(true);
    }
    
    
    /**
     * Fallið sé um að eyða gamla staðsetning sem peð var í
     * @param x er x-hnit
     * @param y er y-hnit
     */
    public void eydaFraBord(int x, int y) {
        int[] r = hvadaReitur(x,y);
        al.eydaPedFraBord(r);
    }
    
    
    /**
     * Fallið skila númer sá sem vinnur leikinn
     * @return 0 ef enginn, 1 ef Hounds vinnur leikinn, 2 ef Hare vinnur leikinn
     */
    public int athVinningur() {
        int vinningurEr = al.skilaVinningshafi();
        return vinningurEr;
    }
    
    
    /**
     * Fallið hvadaReitur tekur við x-hnit og y-hnit
     * 
     * 
     * @param x
     * @param y
     * @return númer reits
     */
    private int[] hvadaReitur(int x, int y) {
        int[] a = new int[2];
        a[0] = 0;
        a[1] = 0;
        for(int i=0; i<3; i++) {
            for(int j=0; j<5; j++) {
                if( !((i==0 && j==0) || (i==2 && j==0) || (i==0 && j==4) || (i==2 && j==4)) ) {
                    if(reitur[i][j].erInnan(x, y)) {
                        a[0] = i;
                        a[1] = j;
                    }    
                }
            }
        }
        return a;
    }
    
    
    public void printNew() {
        fdcontroller.printFC("Caesar");
    }
    
    
    
}
