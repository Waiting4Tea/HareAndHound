/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package is.hi.vidmot;

import is.hi.vinnsla.algoRithm;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;

/**
 *
 * @author Notandi
 */
public class teiknaGrunnbord extends Pane{
    
    private FXMLDocumentController fdcontroller;
    
    private final Reitur[][] reitur = new Reitur[3][5];
    private final Reitur[] rData = new Reitur[11];
    
    private algoRithm al = new algoRithm();
    
    private static final String UTANBORD = "Peð er utan spilaborðið";
    private static final String PEDABORDI = "Peð er þegar á borði";
    
    
    
    public teiknaGrunnbord() {
        stillaPane();
    }
    
    /**
     * Teiknar grunnborð Hare and Hounds á graphics context gc
     * @param gc 
     */
    public void stillaSpilaBord(GraphicsContext gc) {

        // Byrja að teikna alla línur á borðið
        gc.strokeLine(80, 240, 240, 120);
        gc.strokeLine(80, 240, 240, 240);
        gc.strokeLine(80, 240, 240, 360);
        gc.strokeLine(240, 240, 240, 120);
        gc.strokeLine(240, 240, 240, 360);
        
        gc.strokeLine(400, 120, 240, 120);
        gc.strokeLine(400, 240, 400, 120);
        gc.strokeLine(400, 240, 240, 120);
        gc.strokeLine(400, 240, 240, 240);
        gc.strokeLine(400, 240, 240, 360);
        gc.strokeLine(400, 240, 400, 360);
        gc.strokeLine(400, 360, 240, 360);
        
        gc.strokeLine(560, 120, 400, 120);
        gc.strokeLine(560, 120, 400, 240);
        gc.strokeLine(560, 120, 560, 240);
        gc.strokeLine(560, 240, 400, 240);
        gc.strokeLine(560, 360, 560, 240);
        gc.strokeLine(560, 360, 400, 240);
        gc.strokeLine(560, 360, 400, 360);
        
        gc.strokeLine(560, 360, 720, 240);
        gc.strokeLine(560, 240, 720, 240);
        gc.strokeLine(560, 120, 720, 240);
        

        // teikna svo hringir
//        gc.fillOval(690, 210, 60, 60);
//        gc.fillOval(530, 90, 60, 60);
//        gc.fillOval(370, 90, 60, 60);
//        gc.fillOval(210, 90, 60, 60);
//        gc.fillOval(50, 210, 60, 60);
//        gc.fillOval(210, 330, 60, 60);
//        gc.fillOval(370, 330, 60, 60);
//        gc.fillOval(530, 330, 60, 60);
//        gc.fillOval(210, 210, 60, 60);
//        gc.fillOval(370, 210, 60, 60);
//        gc.fillOval(530, 210, 60, 60);
        
        // prufa teikna ferningar fyrst 
        gc.fillRect(690, 210, 60, 60);
        gc.fillRect(530, 90, 60, 60);
        gc.fillRect(370, 90, 60, 60);
        gc.fillRect(210, 90, 60, 60);
        gc.fillRect(50, 210, 60, 60);
        gc.fillRect(210, 330, 60, 60);
        gc.fillRect(370, 330, 60, 60);
        gc.fillRect(530, 330, 60, 60);
        gc.fillRect(210, 210, 60, 60);
        gc.fillRect(370, 210, 60, 60);
        gc.fillRect(530, 210, 60, 60);

        gc.fillRect(50, 90, 60, 60);
    }
    
    /**
     * Frumstilla reitina sem afmarka hverja sellu í spilaborð
     */
    public void stillaPane() {
        int x = 50;
        int y = 90;
        for(int i=0; i<3; i++) {
            for(int j=0; j<5; j++) {
                // x er x-Ás, y er y-Ás og 50 stendur fyrir radíus
                reitur[i][j] = new Reitur(x, y, 60, 60);
                // 60 er breidd af ferningur, 100 er svona space á milli 2 ferningar
                x = x+60+100;
            }
            x = 50;
            // fyrsta 60 er fyrir hæð á ferning, hinn 60 er fyrir space milli 2 ferningar
            y = y+60+60;
        }
    }
    
    /**
     * Fallið setjaABord tekur við x-ás og y-ás 
     * og sé um að gera eftirfarandi hlutverk:
     * 
     * 1. Tilkynna villu þegar færa peð í reit
     *    a. ef peð lendir utan reitur þá gefa villu skilaboð
     *    b. ef það er eitthvað peð á borðið þá skila villu skilaboð
     * 2. setja peð á borðið
     * 3. athuga ef einhver vinnur leikinn
     * 4. að lokum endurstilla alla gildið á borðið í 0
     * @param x er x-ás
     * @param y er y-ás
     */
    public void setjaABord(int x, int y) {
        int[] r = hvadaReitur(x, y);
        if(r[0]==0 && r[1]==0) {
            fdcontroller.tilkynnaVillu(UTANBORD);
            return;
        }
        if(al.erThegarABordi(r)) {
            fdcontroller.tilkynnaVillu(PEDABORDI);
        } else {
            // Setja peð á borð
            al.setjaPedABord(r);
            athVinningur();
        }
        // endurstilla alla gildi á borðið í 0
        al.endurStillaGildi();
    }
    
    
    /**
     * Fallið athVinningur sé um að birta vinningshafi
     * og óvirkja alla takkið
     */
    private void athVinningur() {
        int vinningurEr = al.skilaVinningshafi();
        if(vinningurEr==1) {
            fdcontroller.displayWinner(1);
            fdcontroller.oVirkjaHnappa(true);
        }
        if(vinningurEr==2) {
            fdcontroller.displayWinner(2);
            fdcontroller.oVirkjaHnappa(true);
        }
    }
    
    
    /**
     * Fallið hvadaReitur tekur við x-hnit og y-hnit
     * 
     * @param x
     * @param y
     * @return 
     */
    private int[] hvadaReitur(int x, int y) {
        int[] a = new int[2];
        a[0] = 0;
        a[1] = 0;
        for(int i=0; i<3; i++) {
            for(int j=0; j<3; j++) {
                if(reitur[i][j].erInnan(x, y)) {
                    a[0] = i;
                    a[1] = j;
                }
            }
        }
        return a;
    }

//    public String printNew(String s) {
//        return s + " is a String";
//    }
    
}
