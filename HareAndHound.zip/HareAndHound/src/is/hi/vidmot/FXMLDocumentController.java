/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package is.hi.vidmot;

import is.hi.vinnsla.algoRithm;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Shape;

/**
 *
 * @author Notandi
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private Canvas mittCanvas;
    @FXML
    private Pane realPane;
    @FXML
    private Label skilabod;
    @FXML
    private Label infoLabel;
    @FXML
    private Label infoRules;
    @FXML
    private RadioButton houndsButton;
    @FXML
    private RadioButton hareButton;
    @FXML
    private MenuItem nyrLeikur;
    
//    private HelpGluggiController HelpGluggiController;
//
//    public void setHelpGluggiController(HelpGluggiController h) {
//        HelpGluggiController = h;
//    }



    
    HareAndHound hah = new HareAndHound();
    FXMLDocumentController fdcontroller;
    private Shape shape;
    private teiknaGrunnbord teiknaBord;
    algoRithm algo = new algoRithm();
    Ped ped;
    Hare hare;
    Hounds hounds;
    private boolean winners = false;
    private String winning = "";




    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
//        helpmeController = new HelpGluggiController();
        // private HelpGluggiController helpmeController;
//        HelpGluggiController.initHelpGluggi(this);
//        HelpGluggiController = new HelpGluggiController();
        GraphicsContext gc = mittCanvas.getGraphicsContext2D();
        teiknaBord = new teiknaGrunnbord();
        teiknaBord.stillaSpilaBord(gc);
        
        teiknaBord.setFdcontroller(this);
        // Kalla í Vinnslu
        
        
        hare = new Hare(teiknaBord, realPane);
        hounds = new Hounds(teiknaBord, realPane);

        
        hare.setFdcontroller(this);
        hounds.setFdcontroller(this);
        
        
        if(houndsButton.isSelected()) {
            hare.frestiPedHare();
        }

        tilkynnaVillu("Hounds is now on the hunt");
        prentaRulesHeading(infoRules);
        prentaInfo(infoLabel);
        

    }
    
    /**
     * Radio button til að velja hver á að gera næst
     * @param event 
     */
    @FXML
    private void leikmennButtons(ActionEvent event) {

    }

    /**
     * virka eða óvirka Hounds takkið
     */
    public RadioButton getHoundsButton() {
        return houndsButton;
    }

    
    /**
     * virka eða óvirka Hounds takkið
     */
    public RadioButton getHareButton() {
        return hareButton;
    }
    
    
    
    
    
    
    
    public void frestiOgVirkaPed() {
        if(houndsButton.isSelected()) {
            hare.frestiPedHare();
            hounds.virkaPedHound();
        }
        else if(hareButton.isSelected()) {
            hounds.frestiPedHounds();
            hare.virkaPedHare();
        }
    }
    
    
    
    
    /**
     * Fallið sé um að svissa á radio button-ið
     * @param i 
     */
//    public void naestiLeikmadurGeri(int i) {
//        if(i==1) {
//            houndsButton.setDisable(false);
//            hareButton.setDisable(true);
//        } else if(i==2) {
//            hareButton.setDisable(false);
//            houndsButton.setDisable(true);
//        }
//    }
    
    
//    public void theWinnersIs(boolean b) {
//        winners = b;
//    }

    /**
     * Fallið displayWinner sé um að birta í label 
     * @param leikmadur 
     */
    public void displayWinner(int leikmadur) {
        if(leikmadur == 1) {
            winning = "Hounds Win. \nWinner, Winner, Hare for Dinner";
        }
        if(leikmadur == 2) {
            winning = "Hare Wins. \nI will hunt you down next time";
        } 
        skilabod.setText(winning);
    }
    

    /**
     * Fallið sé um að óvirkja takkanir
     * @param b 
     */
    public void oVirkjaHnappa(Boolean b) {
        houndsButton.setDisable(b);
        hareButton.setDisable(b);
        realPane.setDisable(b);
    }
    
    
    
    
    /**
     * Tilkynna Villu í strengnum s
     * @param s villuskilaboð
     */
    public void tilkynnaVillu(String s) {
        skilabod.setText(s);
    }
    
    /**
     * Fallið mun prenta haus fyrir gefin label
     * @param l er Label
     */
    private void prentaRulesHeading(Label l) {
        l.setText("Rules, Hints and Strategies");
    }
    
    /**
     * Fallið mun prenta texti í gefin Label
     * @param l er Label
     */
    private void prentaInfo(Label l) {
        // Setja Reglu í
        String info = ""
                + "\n\n"
                + "=============== How To Play ================"
                + "\n"
                + "* One player represents the three Hounds, which try to corner "
                + "\n"
                + "    the other player's Hare as it seeks to win by escaping them."
                + "\n"
                + "* The Hounds move first. Each player can move one piece one"
                + "\n"
                + "    step in each turn. "
                + "\n\n"
                + "=============== How To Move ==============="
                + "\n"
                + "* The Hounds can only move forward "
                + "or diagonally (left to right) "
                + "\n"
                + "    or vertically (up and down). "
                + "\n"
                + "* The Hare can move in any direction."
                + "\n\n"
                + "=============== How To Win ================"
                + "\n"
                + "* The Hounds win if they \"trap\" the Hare so that it can no longer move."
                + "\n"
                + "* The Hare wins if it \"escapes\" (gets to the left of all the Hounds)."
                + "\n"
                + "* If the Hounds move vertically ten moves in a row, they are "
                + "\n"
                + "    considered to be \"stalling\" and the Hare wins.";
        l.setText(info);
    }

    /**
     * *
     * Handler fyrir valmyndarstakið hætta Hættir í forritinu
     *
     * @param event
     */
    @FXML
    private void haettaHandler(ActionEvent event) {
        Platform.exit();
        System.exit(0);
    }

    /**
     * Handler fyrir valmyndarstakið nýr leikur í forritinu
     * @param event 
     */
    @FXML
    public void nyrLeikurHandler(ActionEvent event) throws IOException {
        algo.endurStillaGildi();
        algo.frumStillaGildi();
        algo = new algoRithm();
        realPane.setDisable(false);
        realPane.getChildren().clear();
        teiknaBord = new teiknaGrunnbord();
        
        hare = new Hare(teiknaBord, realPane);
        hounds = new Hounds(teiknaBord, realPane);

        
        houndsButton.setDisable(false);
        hareButton.setDisable(true);
        hareButton.setSelected(false);
        houndsButton.setSelected(true);
        tilkynnaVillu("Hounds is now on the hunt");

    }
    
    public Pane getRealPane() {
        return realPane;
    }
    
    public void printFC(String s) {
        System.out.println(s + "Julius");
    }

    @FXML
    private void surrenderAction(ActionEvent event) {
        if(houndsButton.isSelected())
        {
            teiknaBord.winnerHare();
        }
        if(hareButton.isSelected()) 
        {
            teiknaBord.winnerHounds();
        }
    }

    @FXML
    private void rulesAction(ActionEvent event) {
        
    }

}
