/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package is.hi.vidmot;

import is.hi.vinnsla.algoRithm;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;

/**
 *
 * @author Notandi
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private Canvas mittCanvas;
    @FXML
    private ToggleGroup groupOne;
    @FXML
    private Pane realPane;
    @FXML
    private Label skilabod;
    @FXML
    private Label infoLabel;
    @FXML
    private Label infoRules;
    @FXML
    private RadioButton houndsButton;
    @FXML
    private RadioButton hareButton;

    
    
    private Shape shape;
    private teiknaGrunnbord teiknaBord = new teiknaGrunnbord();
    algoRithm algo = new algoRithm();
    Hare hare;
    Hounds hounds;
    private boolean winners = false;
    private String winning = "";



    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        GraphicsContext gc = mittCanvas.getGraphicsContext2D();

        teiknaBord.stillaSpilaBord(gc);
        // Kalla í Vinnslu

        hare = new Hare(teiknaBord, realPane);
        hounds = new Hounds(teiknaBord, realPane);
        
        prentaRulesHeading(infoRules);
        prentaInfo(infoLabel);

    }
    
    /**
     * Radio button til að velja hver á að gera næst
     * @param event 
     */
    @FXML
    private void leikmennButtons(ActionEvent event) {
        // byrja að hreinsa skilaboð
        tilkynnaVillu("");
        if(winners == false && houndsButton.isSelected()) {
            // búa til fall HoundsGera(); til að Hounds gera
            naestiLeikmadurGeri(2);
        } 
        else if(winners == false && hareButton.isSelected()) {
            // búa til fall hareGera(); til að Hare gera
            naestiLeikmadurGeri(1);
        }
        else if(winners == true) {
            oVirkjaHnappa(true);
            skilabod.setText(winning);
        }
    }

    
    /**
     * Fallið sé um að svissa á radio button-ið
     * @param i 
     */
    private void naestiLeikmadurGeri(int i) {
        if(i==1) {
            houndsButton.setDisable(false);
            hareButton.setDisable(true);
        } else if(i==2) {
            hareButton.setDisable(false);
            houndsButton.setDisable(true);
        }
    }
    
    
//    public void theWinnersIs(boolean b) {
//        winners = b;
//    }

    /**
     * Fallið displayWinner sé um að birta í label 
     * @param leikmadur 
     */
    public void displayWinner(int leikmadur) {
        if(leikmadur == 1) {
            winning = "Hounds Win";
        }
        if(leikmadur == 2) {
            winning = "Hare Wins";
        } 
        skilabod.setText(winning);
    }
    

    /**
     * Fallið sé um að óvirkja takkanir
     * @param b 
     */
    public void oVirkjaHnappa(Boolean b) {
        houndsButton.setDisable(b);
        hareButton.setDisable(b);
        realPane.setDisable(b);
    }
    
    
    
    
    /**
     * Tilkynna Villu í strengnum s
     * @param s villuskilaboð
     */
    public void tilkynnaVillu(String s) {
        skilabod.setText(s);
    }
    
    /**
     * Fallið mun prenta haus fyrir gefin label
     * @param l er Label
     */
    private void prentaRulesHeading(Label l) {
        l.setText("Rules, Hints and Strategies");
    }
    
    /**
     * Fallið mun prenta texti í gefin Label
     * @param l er Label
     */
    private void prentaInfo(Label l) {
        // Setja Reglu í
        String info = ""
                + "\n\n"
                + "=============== How To Play ================"
                + "\n"
                + "* One player represents the three Hounds, which try to corner "
                + "\n"
                + "    the other player's Hare as it seeks to win by escaping them."
                + "\n"
                + "* The Hounds move first. Each player can move one piece one"
                + "\n"
                + "    step in each turn. "
                + "\n\n"
                + "=============== How To Move ==============="
                + "\n"
                + "* The Hounds can only move forward "
                + "or diagonally (left to right) "
                + "\n"
                + "    or vertically (up and down). "
                + "\n"
                + "* The Hare can move in any direction."
                + "\n\n"
                + "=============== How To Win ================"
                + "\n"
                + "* The Hounds win if they \"trap\" the Hare so that it can no longer move."
                + "\n"
                + "* The Hare wins if it \"escapes\" (gets to the left of all the Hounds)."
                + "\n"
                + "* If the Hounds move vertically ten moves in a row, they are "
                + "\n"
                + "    considered to be \"stalling\" and the Hare wins.";
        l.setText(info);
    }

    /**
     * *
     * Handler fyrir valmyndarstakið hætta Hættir í forritinu
     *
     * @param event
     */
    @FXML
    private void haettaHandler(ActionEvent event) {
        Platform.exit();
        System.exit(0);
    }

    /**
     * Handler fyrir valmyndarstakið nýr leikur í forritinu
     * @param event 
     */
    @FXML
    private void nyrLeikurHandler(ActionEvent event) {
        teiknaBord = new teiknaGrunnbord();
        realPane.getChildren().clear();
        hare = new Hare(teiknaBord, realPane);
        hounds = new Hounds(teiknaBord, realPane);
    }

}
