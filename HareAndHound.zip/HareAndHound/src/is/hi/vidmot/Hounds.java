/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package is.hi.vidmot;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Shape;

/**
 *
 * @author Notandi
 */
public class Hounds extends Ped {
    
    
    public Hounds(teiknaGrunnbord b, Pane pane) {
        super(b, pane);
        HoundsPed(pane);
    }
    
    /**
     * Búa til peð fyrir hounds
     * @param pane Pane
     */
    public void HoundsPed(Pane pane) {
        pedHs1 = new Circle(18, Color.DARKORANGE);
        pedHs1.relocate(65, 226);
        pane.getChildren().add(pedHs1);
        pedHs1.setOnMouseDragged(mouseDraggedHs1);
        pedHs1.setOnMouseReleased(mouseReleasedCircleHs1);
        
        pedHs2 = new Circle(18, Color.DARKORANGE);
        pedHs2.relocate(225, 106); 
        pane.getChildren().add(pedHs2);
        pedHs2.setOnMouseDragged(mouseDraggedHs2);
        pedHs2.setOnMouseReleased(mouseReleasedCircleHs2);
        
        pedHs3 = new Circle(18, Color.DARKORANGE);
        pedHs3.relocate(225, 346);
        pane.getChildren().add(pedHs3);        
        pedHs3.setOnMouseDragged(mouseDraggedHs3);
        pedHs3.setOnMouseReleased(mouseReleasedCircleHs3);
    }
    

    /**
     * mouse dragged option for hound 1
     */
    private final EventHandler<MouseEvent> mouseDraggedHs1 =
            new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    // ef nýlega að færa hinn hounds þá 
                    if(pedHs2.getStrokeWidth()!=0) {
                        pedHs2.setStrokeWidth(0);
                    }
                    if(pedHs3.getStrokeWidth()!=0) {
                        pedHs3.setStrokeWidth(0);
                    }
                    pedHs1.setStroke(Color.RED);
                    pedHs1.setStrokeWidth(5);
                    faeraHlut(pedHs1, event);
                    
                }
            };
    /**
     * mouse released option for hound 1
     */
    private final EventHandler<MouseEvent> mouseReleasedCircleHs1 =
            new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
//                    bord.setjaABord((int)((Circle)pedHs1).getCenterX(),
//                                    (int)((Circle)pedHs1).getCenterY());

//                    pedHs1.setOnMouseDragged(null);
//                    pedHs2.setOnMouseDragged(null);
//                    pedHs3.setOnMouseDragged(null);

                }
            };

    
    
    /**
     * mouse dragged option for hound 2
     */
    private final EventHandler<MouseEvent> mouseDraggedHs2 =
            new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    if(pedHs1.getStrokeWidth()!=0) {
                        pedHs1.setStrokeWidth(0);
                    }
                    if(pedHs3.getStrokeWidth()!=0) {
                        pedHs3.setStrokeWidth(0);
                    }
                    pedHs2.setStroke(Color.RED);
                    pedHs2.setStrokeWidth(5);
                    faeraHlut(pedHs2, event);
                }
            };
    
    /**
     * mouse released option for hound 2
     */
    private final EventHandler<MouseEvent> mouseReleasedCircleHs2 =
            new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
//                    bord.setjaABord((int)((Circle)pedHs2).getCenterX(),
//                                    (int)((Circle)pedHs2).getCenterY());

//                    pedHs1.setOnMouseDragged(null);
//                    pedHs2.setOnMouseDragged(null);
//                    pedHs3.setOnMouseDragged(null);

                } 
            };
    
    
    
    
    
    /**
     * mouse dragged option for hound 3
     */
    private final EventHandler<MouseEvent> mouseDraggedHs3 =
            new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    if(pedHs1.getStrokeWidth()!=0) {
                        pedHs1.setStrokeWidth(0);
                    }
                    if(pedHs2.getStrokeWidth()!=0) {
                        pedHs2.setStrokeWidth(0);
                    }
                    pedHs3.setStroke(Color.RED);
                    pedHs3.setStrokeWidth(5);
                    faeraHlut(pedHs3, event);
                }
            };
    
    /**
     * mouse released option for hound 3
     */
    private final EventHandler<MouseEvent> mouseReleasedCircleHs3 =
            new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
//                    bord.setjaABord((int)((Circle)pedHs3).getCenterX(),
//                                    (int)((Circle)pedHs3).getCenterY());

//                    pedHs1.setOnMouseDragged(null);
//                    pedHs2.setOnMouseDragged(null);
//                    pedHs3.setOnMouseDragged(null);

                }
            };
    
    
    
    
    /**
     * færa hring
     * @param s er shape sem mun tekur inn hring í þetta verkefni
     * @param event fyrir dragged atburð
     */
    @Override
    protected void faeraHlut(Shape s, MouseEvent event) {
        ((Circle)s).setCenterX(event.getX());
        ((Circle)s).setCenterY(event.getY());
    }
}
