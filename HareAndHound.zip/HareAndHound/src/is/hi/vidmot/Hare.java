/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package is.hi.vidmot;

import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Shape;

/**
 *
 * @author Notandi
 */
public class Hare extends Ped {
    
    /**
     * Smiðurinn fyrir Hare
     * @param pane Pane
     */
    public Hare (teiknaGrunnbord b, Pane pane) {
        super(b, pane);
        HarePed(pane); 
    }
    
    
    /**
     * Fallið sé um að búa til Hare peð í Pane
     * @param pane er Pane
     */
    public void HarePed(Pane pane) {
        pedHare = new Circle(16,Color.LIGHTGOLDENRODYELLOW);
        pedHare.relocate(705, 226);
        pane.getChildren().add(pedHare);
        pedHare.setOnMouseDragged(mouseDragged);
        pedHare.setOnMouseReleased(mouseReleasedCircleHare);
        
    }

    
    /**
     * Atburðarhandler fyrir þegar músin er dregin
     * Peðið er fært
     */
    private final EventHandler<MouseEvent> mouseDragged =
            new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    
                    pedHare.setStroke(Color.RED);
                    pedHare.setStrokeWidth(5);
                    faeraHlut(pedHare, event);
                    /*System.out.println("X-hnit: "
                            + event.getSceneX()
                            + "     Y-hnit: "
                            + event.getSceneY()
                    );*/
                    
                    
                }
            };

    /**
     * Atburðarhandler fyrir þegar músin er sleppt
     * Peðið mun vera fastur eftir á
     */
    private final EventHandler<MouseEvent> mouseReleasedCircleHare =
            new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {

                      System.out.print("sceneX: " + event.getSceneX());
                      System.out.print(" sceneY: " + event.getSceneY());
                      System.out.println();
                      System.out.print(" centerX: " + ((Circle)pedHare).getCenterX());
                      System.out.print(" centerY: " + ((Circle)pedHare).getCenterY());
                      System.out.println();
                    // ef peð fer á réttum stað þá fresti peð 
                    // pedHare.setOnMouseDragged(null);
                }
            };
      
    /**
     * Færir hring s í x,y hnit á event
     * @param s hringur
     * @param event upplýsingar um released atburðurinn - notum (x,y)
     */
    @Override
    protected void faeraHlut(Shape s, MouseEvent event) {
        ((Circle)s).setCenterX(event.getX());
        ((Circle)s).setCenterY(event.getY());

    }
}
