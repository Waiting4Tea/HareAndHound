/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package is.hi.vidmot;

import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Shape;

/**
 *
 * @author Notandi
 */
public class Hare extends Ped {
    

    /**
     * Smiðurinn fyrir Hare
     * @param pane Pane
     */
    public Hare (teiknaGrunnbord b, Pane pane) {
        super(b, pane);
        HarePed(pane);
    }
    
    
    /**
     * Fallið sé um að búa til Hare peð í Pane
     * @param pane er Pane
     */
    public void HarePed(Pane pane) {
        pedHare = new Circle(720, 240 ,16,Color.LIGHTGOLDENRODYELLOW);
//        pedHare.relocate(705, 226);
        pane.getChildren().add(pedHare);

        pedHare.setOnMousePressed(mouseClicked);
        pedHare.setOnMouseDragged(mouseDragged);
        pedHare.setOnMouseReleased(mouseReleasedCircleHare);

    }
    
    public void frestiPedHare() {
        pedHare.setOnMouseClicked(null);
        pedHare.setOnMousePressed(null);
        pedHare.setOnMouseDragged(null);
//        pedHare.removeEventHandler(MouseEvent.MOUSE_DRAGGED, mouseDragged);
//        pedHare.addEventHandler(MouseEvent.MOUSE_DRAGGED, mouseDragged);
    }
    
    public void virkaPedHare() {
        pedHare.setOnMousePressed(mouseClicked);
        pedHare.setOnMouseDragged(mouseDragged);
        pedHare.setOnMouseReleased(mouseReleasedCircleHare);
    }
    
    private final EventHandler<MouseEvent> mouseClicked =
            new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {

//                    System.out.println("X-hnit: "
//                            + event.getSceneX()
//                            + "     Y-hnit: "
//                            + event.getSceneY()
//                    );
                    int x = (int)(event.getSceneX());
                    int y = (int)(event.getSceneY());
                    bord.eydaFraBord(x, y);
                    
                    // if old position = new position => tilkynna að Ped
                    // er á saman stað og færðu peðið
//                    System.out.println("Center X: " + (int)((Circle)pedHs1).getCenterX());
//                    System.out.println("Center Y :" + (int)((Circle)pedHs1).getCenterY());
//                    System.out.println("Event X: " + event.getX());
//                    System.out.println("Event Y: " + event.getY());
//                    if(fdcontroller.isHareSelected()) {
//                        pedHs1.setOnMouseDragged(null);
//                        pedHs2.setOnMouseDragged(null);
//                        pedHs3.setOnMouseDragged(null);
//                    }
                }
            };

    
    /**
     * Atburðarhandler fyrir þegar músin er dregin
     * Peðið er fært
     */
    private final EventHandler<MouseEvent> mouseDragged =
            new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    pedHare.setStroke(Color.RED);
                    pedHare.setStrokeWidth(5);
                    faeraHlut(pedHare, event);
                }
            };

    /**
     * Atburðarhandler fyrir þegar músin er sleppt
     * Peðið mun vera fastur eftir á
     */
    private final EventHandler<MouseEvent> mouseReleasedCircleHare =
            new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    System.out.println("X: " + event.getX());
                    System.out.println("Y: " + event.getY());

                    bord.setjaABord((int)((Circle)pedHare).getCenterX(),
                                    (int)((Circle)pedHare).getCenterY());
                    // ef peð fer á réttum stað þá fresti peð 
                    // pedHare.setOnMouseDragged(null);
                    
                    if(bord.athVinningur() == 1 && bord.athVinningur() == 2) {
                        frestiPedHare();
                    }

                }
            };
      
    /**
     * Færir hring s í x,y hnit á event
     * @param s hringur
     * @param event upplýsingar um released atburðurinn - notum (x,y)
     */
    @Override
    protected void faeraHlut(Shape s, MouseEvent event) {
        ((Circle)s).setCenterX(event.getX());
        ((Circle)s).setCenterY(event.getY());
    }

    public void printT(String s) {
        System.out.println("Hello " + s);
    }
}
