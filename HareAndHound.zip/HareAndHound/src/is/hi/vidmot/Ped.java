/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package is.hi.vidmot;

import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Shape;

/**
 *
 * @author Notandi
 */
public abstract class Ped {
    
    protected teiknaGrunnbord bord;
    protected Pane realpane;
    
    // Hare peð
    protected Shape pedHare;
    
    // Hounds peð
    protected Shape pedHs1;
    protected Shape pedHs2;
    protected Shape pedHs3;
    
    public Ped(teiknaGrunnbord b, Pane pane) {
        bord = b;
        realpane = pane;
    }

    
    /**
     * Notum þetta fall þegar búinn er að setja Shape inn fyrir peð
     * Notið fallið til þess að skila ped 
     * TD: setja ped = new Circle(200 ,200 ,10);
     *     og þá er ped með Circle í Shape
     * @return ped
     */
    public Shape getPedHare() {
        return pedHare;
    }

    public Shape getPedHs1() {
        return pedHs1;
    }

    public Shape getPedHs2() {
        return pedHs2;
    }

    public Shape getPedHs3() {
        return pedHs3;
    }
    
    
    /**
     * Færir  peð s í staðsetningu (x,y) í event 
     *
     * @param s    hluturinn sem á að færa 
     * @param event upplýsingar um released atburðurinn - notum (x,y)
     */
    protected abstract void faeraHlut(Shape s, MouseEvent event);
}
