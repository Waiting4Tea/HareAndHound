/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package is.hi.vinnsla;

/**
 *
 * @author Notandi
 */
public class algoRithm {

    int[][] bord = new int[3][5];
    int nuverandiLeikmadur = 1;

    int dalkurHs1 = 0;
    int dalkurHs2 = 0;
    int dalkurHs3 = 0;
    int dalkurHare = 0;

    /**
     * Smiðurinn.
     */
    public algoRithm() {
        // Frumstilla borðið. Ekkert peð er á því
        frumStillaGildi();
    }
    
    /**
     * Frum stilla gildi á borðið í byrjun.
     */
    public void frumStillaGildi() {
        for(int i=0; i<3; i++) {
            for(int j=0; j<5; j++) {
                if( (i==1 && j==0) || (i==0 && j==1) || (i==2 && j==1) ) {
                    bord[i][j] = 1;
                }
                else if(i==1 && j==4) {
                    bord[i][j] = 2;
                }
                else bord[i][j] = 0;
            }
        }
    }
    
    /**
     * nuverandiLeikmadur gerir
     * @param nuverandiLeikmadur 
     */
    public void setNuverandiLeikmadur(int n) {
        nuverandiLeikmadur = n;
    }

    /**
     * Get aðferð fyrir tilviksbreytu nuverandiLeikmadur
     * @return 
     */
    public int getNuverandiLeikmadur() {
        return nuverandiLeikmadur;
    }
    
    /**
     * Fallið endurStillaGildi sé um að hreinsa alla gildi á borðið.
     */
    public void endurStillaGildi() {
        for(int i=0; i<3; i++) {
            for(int j=0; j<5; j++) {
                bord[i][j] = 0;
            }
        }
    }
    
    /**
     * Fallið prenta spilaborð í terminal
     */
    public void prentaBord() {
        for(int i=0; i<3; i++) {
            for(int j=0; j<5; j++) {
                System.out.print(bord[i][j] + " ");
            }
            System.out.println();
        }
    }
    
    /**
     * Skila vinningshafi.
     * @return 0 ef engin vann, 1 ef Hounds vann, 2 ef Hare vann.
     */
    public int skilaVinningshafi() {
        return tekkaVinningur(bord);
    }
    
    /**
     * Nota fallið til að ath á vinningur.
     * skila 2 ef Hare vann leikinn, 1 ef Hounds vann leikinn, 0 ef eingin vann.
     * @param a er spilatöflu sem er í formið 2d array.
     * @return vinningur.
     */
    private int tekkaVinningur(int[][] a) {
	  int vinningur = 0;
	  // Hounds er með tölu 1
	  // Hare er með tölu 2
	  // tómt svæði er 0

	  // ATH HOUNDS WINS
	  // allt að 3 möguleikar
	  // möguleika 1 þegar Hare er læst inná svæði a[0][2]
	  if(a[0][1]==1 && a[1][2]==1 && a[0][3]==1 && a[0][2]==2){
	      vinningur = 1;
	      return vinningur;
	  }
	  // möguleika 2 þegar Hare er læst inná svæði a[2][2]
	  if(a[2][1]==1 && a[1][2]==1 && a[2][3]==1 && a[2][2]==2) {
	      vinningur = 1;
	      return vinningur;
	  }
	  // möguleika 3 þegar Hare er læst inná svæði a[1][4]
	  if(a[0][3]==1 && a[1][3]==1 && a[2][3]==1 && a[1][4]==2) {
	      vinningur = 1;
	      return vinningur;
	  }



	  // ATH HARE WINS
	  // Hare vann þegar er í miðju spilaborð í eftirfarandi svæði
	  // möguleika 1 þegar Hare er í svæði a[1][1]
	  if(a[1][1]==2 && (a[0][1]==1 || a[2][1]==1) && isNoHoundsOTL(a,1)==true) {
	      vinningur = 2;
	      return vinningur;
	  }
	  // möguleika 2 þegar Hare er í svæði a[1][2]
	  if(a[1][2]==2 && (a[0][2]==1 || a[2][2]==1) && isNoHoundsOTL(a,2)==true) {
	      vinningur = 2;
	      return vinningur;
	  }
	  // möguleika 3 þegar Hare er í svæði a[1][3]
	  if(a[1][3]==2 && (a[0][3]==1 || a[2][3]==1) && isNoHoundsOTL(a,3)==true) {
	      vinningur = 2;
	      return vinningur;
	  }

	  // Hare vann þegar er í efri spilaborð í eftirfarandi svæði
	  // möguleika 1 þegar Hare er í svæði a[0][1]
	  if(a[0][1]==2 && (a[1][1]==1 || a[2][1]==1) && isNoHoundsOTL(a,1)==true ) {
	      vinningur = 2;
	      return vinningur;
	  }
	  // möguleika 2 þegar Hare er í svæði a[0][2]
	  if(a[0][2]==2 && (a[1][2]==1 || a[2][2]==1) && isNoHoundsOTL(a,2)==true) {
	      vinningur = 2;
	      return vinningur;
	  }
	  // möguleika 3 þegar Hare er í svæði a[0][3]
	  if(a[0][3]==2 && (a[1][3]==1 || a[2][3]==1) && isNoHoundsOTL(a,3)==true) {
	      vinningur = 2;
	      return vinningur;
	  }

	  // Hare vann þegar er í neðri spilaborð í eftirfarandi svæði
	  // möguleika 1 þegar Hare er í svæði a[2][1]
	  if(a[2][1]==2 && (a[0][1]==1 || a[1][1]==1) && isNoHoundsOTL(a,1)==true) {
	      vinningur = 2;
	      return vinningur;
	  }
	  // möguleika 2 þegar Hare er í svæði a[2][2]
	  if(a[2][2]==2 && (a[0][2]==1 || a[1][2]==1) && isNoHoundsOTL(a,2)==true) {
	      vinningur = 2;
	      return vinningur;
	  }
	  // möguleika 3 þegar Hare er í svæði a[2][3]
	  if(a[2][3]==2 && (a[0][3]==1 || a[1][3]==1) && isNoHoundsOTL(a,3)==true) {
	      vinningur = 2;
	      return vinningur;
	  }
	  return vinningur;
    }

    /**
     * Fallið is_No_Hounds_On_The_Left tákna sem isNoHoundsOTL
     * tekur inn númer dálka sem Hare er í
     * og síðan ath á alla dálkar sem er vinstra megin
     * af því
     * @param a er spilaborð
     * @param column er dálka sem Hare er núna staðsett
     * @return true ef það er ekkert Hounds annars false
     */
    private boolean isNoHoundsOTL(int[][] a, int column) {
	  for(int i=0; i<3; i++) {
	      for(int j=0; j<column; j++) {
		  if(a[i][j]==1) {
		      return false;
		  }
	      }
	  }
	  return true;
    }
    
    /**
     * Fallið er nota til að athuga hvort peð er á borðið
     * @param a
     * @return 
     */
    public boolean erThegarABordi(int[] a) {
        int i = a[0];
        int j = a[1];
         // hounds er 1, hare er 2
        if(bord[i][j] == 1 || bord[i][j] == 2) {
            System.out.println("Peð á borð");
            return true;
        }
        return false;
    }
    
    /**
     * Fallið setjaPedABord sé um að setja gildi í borðið
     * @param a er fylkið sem inniheldur númer línu og dálku sem 
     * peð er í
     */
    public void setjaPedABord(int[] a) {
        int i = a[0];
        int j = a[1];
        bord[i][j] = nuverandiLeikmadur;
    }
    
    /**
     * Fallið eydaPedFraBord sé um að eyða gildi peð frá borðið
     * @param a er fylkið sem inniheldur númer línu og dálku sem 
     * peð er í
     */
    public void eydaPedFraBord(int[] a) {
        int i = a[0];
        int j = a[1];
        bord[i][j] = 0;
    }
    

    
}
