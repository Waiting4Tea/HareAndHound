/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package is.hi.vinnsla;

/**
 *
 * @author Notandi
 */
public class algoRithm {
    
    private static final int LEIKMENN = 2;
    private final int[] Leikmadur = {1, 2}; // hounds er 1, hare er 2
    
    int[][] bord = new int[3][5];
    int nuverandiLeikmadur = 1;


    /**
     * Smiðurinn.
     */
    public algoRithm() {
        // Frumstilla borðið. Ekkert peð er á því
        for(int i=0; i<3; i++) {
            for(int j=0; j<5; j++) {
                bord[i][j] = 0;
            }
        }
    }
    
    /**
     * Fallið endurStillaGildi sé um að hreinsa alla gildi á borðið.
     */
    public void endurStillaGildi() {
        for(int i=0; i<3; i++) {
            for(int j=0; j<5; j++) {
                bord[i][j] = 0;
            }
        }
    }
    
    /**
     * Skila vinningshafi.
     * @return 0 ef engin vann, 1 ef Hounds vann, 2 ef Hare vann.
     */
    public int skilaVinningshafi() {
        return tekkaVinningur(bord);
    }
    
    /**
     * Nota fallið til að ath á vinningur.
     * skila 1 ef Hare vann leikinn, 2 ef Hounds vann leikinn, 0 ef eingin vann.
     * @param a er spilatöflu sem er í formið 2d array.
     * @return vinningur.
     */
    private int tekkaVinningur(int[][] a) {
	  int vinningur = 0;
	  // Hounds er með tölu 1
	  // Hare er með tölu 2
	  // tómt svæði er 0

	  // ATH HOUNDS WINS
	  // allt að 3 möguleikar
	  // möguleika 1 þegar Hare er læst inná svæði a[0][2]
	  if(a[0][1]==1 && a[1][2]==1 && a[0][3]==1 && a[0][2]==2){
	      vinningur = 1;
	      return vinningur;
	  }
	  // möguleika 2 þegar Hare er læst inná svæði a[2][2]
	  if(a[2][1]==1 && a[1][2]==1 && a[2][3]==1 && a[2][2]==2) {
	      vinningur = 1;
	      return vinningur;
	  }
	  // möguleika 3 þegar Hare er læst inná svæði a[1][4]
	  if(a[0][3]==1 && a[1][3]==1 && a[2][3]==1 && a[1][4]==2) {
	      vinningur = 1;
	      return vinningur;
	  }



	  // ATH HARE WINS
	  // Hare vann þegar er í miðju spilaborð í eftirfarandi svæði
	  // möguleika 1 þegar Hare er í svæði a[1][1]
	  if(a[1][1]==1 && (a[0][1]==2 || a[2][1]==2) && isNoHoundsOTL(a,1)==true) {
	      vinningur = 2;
	      return vinningur;
	  }
	  // möguleika 2 þegar Hare er í svæði a[1][2]
	  if(a[1][2]==1 && (a[0][2]==2 || a[2][2]==2) && isNoHoundsOTL(a,2)==true) {
	      vinningur = 2;
	      return vinningur;
	  }
	  // möguleika 3 þegar Hare er í svæði a[1][3]
	  if(a[1][3]==1 && (a[0][3]==2 || a[2][3]==2) && isNoHoundsOTL(a,3)==true) {
	      vinningur = 2;
	      return vinningur;
	  }

	  // Hare vann þegar er í efri spilaborð í eftirfarandi svæði
	  // möguleika 1 þegar Hare er í svæði a[0][1]
	  if(a[0][1]==1 && (a[1][1]==2 || a[2][1]==2) && isNoHoundsOTL(a,1)==true ) {
	      vinningur = 2;
	      return vinningur;
	  }
	  // möguleika 2 þegar Hare er í svæði a[0][2]
	  if(a[0][2]==1 && (a[1][2]==2 || a[2][2]==2) && isNoHoundsOTL(a,2)==true) {
	      vinningur = 2;
	      return vinningur;
	  }
	  // möguleika 3 þegar Hare er í svæði a[0][3]
	  if(a[0][3]==1 && (a[1][3]==2 || a[2][3]==2) && isNoHoundsOTL(a,3)==true) {
	      vinningur = 2;
	      return vinningur;
	  }

	  // Hare vann þegar er í neðri spilaborð í eftirfarandi svæði
	  // möguleika 1 þegar Hare er í svæði a[2][1]
	  if(a[2][1]==1 && (a[0][1]==2 || a[1][1]==2) && isNoHoundsOTL(a,1)==true) {
	      vinningur = 2;
	      return vinningur;
	  }
	  // möguleika 2 þegar Hare er í svæði a[2][2]
	  if(a[2][2]==1 && (a[0][2]==2 || a[1][2]==2) && isNoHoundsOTL(a,2)==true) {
	      vinningur = 2;
	      return vinningur;
	  }
	  // möguleika 3 þegar Hare er í svæði a[2][3]
	  if(a[2][3]==1 && (a[0][3]==2 || a[1][3]==2) && isNoHoundsOTL(a,3)==true) {
	      vinningur = 2;
	      return vinningur;
	  }
	  return vinningur;
    }

    /**
     * Fallið is_No_Hounds_On_The_Left tákna sem isNoHoundsOTL
     * tekur inn númer dálka sem Hare er í
     * og síðan ath á alla dálkar sem er vinstra megin
     * af því
     * @param a er spilaborð
     * @param column er dálka sem Hare er núna staðsett
     * @return true ef það er ekkert Hounds annars false
     */
    private boolean isNoHoundsOTL(int[][] a, int column) {
	  for(int i=0; i<3; i++) {
	      for(int j=0; j<column; j++) {
		  if(a[i][j]==2) {
		      return false;
		  }
	      }
	  }
	  return true;
    }
    
    /**
     * Fallið er nota til að athuga hvort peð er á borðið
     * @param a
     * @return 
     */
    public boolean erThegarABordi(int[] a) {
        int i = a[0];
        int j = a[1];
        if(bord[i][j] == Leikmadur[0] || bord[i][j] == Leikmadur[1]) {
            return true;
        }
        return false;
    }
    
    /**
     * Fallið setjaPedABord sé um að setja gildi í borðið
     * @param a 
     */
    public void setjaPedABord(int[] a) {
        int i = a[0];
        int j = a[1];
        bord[i][j] = nuverandiLeikmadur;
    }
    
    
    /**
     * nuverandiLeikmadur gerir
     * @param nuverandiLeikmadur 
     */
    public void setNuverandiLeikmadur(int nuverandiLeikmadur) {
        nuverandiLeikmadur = nuverandiLeikmadur;
    }

    /**
     * Get aðferð fyrir tilviksbreytu nuverandiLeikmadur
     * @return 
     */
    public int getNuverandiLeikmadur() {
        return nuverandiLeikmadur;
    }
    
}
