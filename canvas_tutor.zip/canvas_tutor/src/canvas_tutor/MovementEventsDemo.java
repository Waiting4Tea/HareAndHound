/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package canvas_tutor;


 /*
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcType;
import javafx.stage.Stage;

public class canvas_tutor extends Application {
 
    public static void main(String[] args) {
        launch(args);
    }
 
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Drawing Operations Test");
        Group root = new Group();
        Canvas canvas = new Canvas(300, 250);
        GraphicsContext gc = canvas.getGraphicsContext2D();
        drawShapes(gc);
        root.getChildren().add(canvas);
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }

    private void drawShapes(GraphicsContext gc) {
        gc.setFill(Color.GREEN);
        gc.setStroke(Color.BLUE);
        gc.setLineWidth(5);
        gc.strokeLine(40, 10, 10, 40);
        gc.fillOval(10, 60, 30, 30);
        gc.strokeOval(60, 60, 30, 30);
        gc.fillRoundRect(110, 60, 30, 30, 10, 10);
        gc.strokeRoundRect(160, 60, 30, 30, 10, 10);
        gc.fillArc(10, 110, 30, 30, 45, 240, ArcType.OPEN);
        gc.fillArc(60, 110, 30, 30, 45, 240, ArcType.CHORD);
        gc.fillArc(110, 110, 30, 30, 45, 240, ArcType.ROUND);
        gc.strokeArc(10, 160, 30, 30, 45, 240, ArcType.OPEN);
        gc.strokeArc(60, 160, 30, 30, 45, 240, ArcType.CHORD);
        gc.strokeArc(110, 160, 30, 30, 45, 240, ArcType.ROUND);
        gc.fillPolygon(new double[]{10, 40, 10, 40},
                       new double[]{210, 210, 240, 240}, 4);
        gc.strokePolygon(new double[]{60, 90, 60, 90},
                         new double[]{210, 210, 240, 240}, 4);
        gc.strokePolyline(new double[]{110, 140, 110, 140},
                          new double[]{210, 210, 240, 240}, 4);
    }
}
*/
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.*;
import javafx.scene.control.Label;
import javafx.scene.input.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class MovementEventsDemo extends Application {
  private static final int      KEYBOARD_MOVEMENT_DELTA = 5;
  private static final Duration TRANSLATE_DURATION      = Duration.seconds(0.25);

  public static void main(String[] args) { launch(args); }
  @Override public void start(Stage stage) throws Exception {
    final Circle circle = createCircle();
    final Group group = new Group(createInstructions(), circle);
    final TranslateTransition transition = createTranslateTransition(circle);
    
    final Scene scene = new Scene(group, 600, 400, Color.CORNSILK);
    moveCircleOnKeyPress(scene, circle);
    moveCircleOnMousePress(scene, circle, transition);
    
    stage.setScene(scene);
    stage.show();
  }

  private Label createInstructions() {
    Label instructions = new Label(
      "Use the arrow keys to move the circle in small increments\n" +
      "Click the mouse to move the circle to a given location\n" +
      "Ctrl + Click the mouse to slowly translate the circle to a given location"      
    );
    instructions.setTextFill(Color.FORESTGREEN);
    return instructions;
  }

  private Circle createCircle() {
    final Circle circle = new Circle(200, 150, 50, Color.BLUEVIOLET);
    //circle.setOpacity(0.7);
    return circle;
  }

  private TranslateTransition createTranslateTransition(final Circle circle) {
    final TranslateTransition transition = new TranslateTransition(TRANSLATE_DURATION, circle);
    transition.setOnFinished(new EventHandler<ActionEvent>() {
      @Override public void handle(ActionEvent t) {
        circle.setCenterX(circle.getTranslateX() + circle.getCenterX());
        circle.setCenterY(circle.getTranslateY() + circle.getCenterY());
        circle.setTranslateX(0);
        circle.setTranslateY(0);
      }
    });
    return transition;
  }

  private void moveCircleOnKeyPress(Scene scene, final Circle circle) {
    scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
      @Override public void handle(KeyEvent event) {
        switch (event.getCode()) {
          case UP:    circle.setCenterY(circle.getCenterY() - KEYBOARD_MOVEMENT_DELTA); break;
          case RIGHT: circle.setCenterX(circle.getCenterX() + KEYBOARD_MOVEMENT_DELTA); break;
          case DOWN:  circle.setCenterY(circle.getCenterY() + KEYBOARD_MOVEMENT_DELTA); break;
          case LEFT:  circle.setCenterX(circle.getCenterX() - KEYBOARD_MOVEMENT_DELTA); break;
        }
//        System.out.println("X: " + circle.getCenterX() 
//                + "--  Y: " + circle.getCenterY()
//                + "-- Radius: " + circle.getRadius());
      }
    });
  }

  private void moveCircleOnMousePress(Scene scene, final Circle circle, final TranslateTransition transition) {
    scene.setOnMousePressed(new EventHandler<MouseEvent>() {
      @Override public void handle(MouseEvent event) {
        if (!event.isControlDown()) {
          circle.setCenterX(event.getSceneX());
          circle.setCenterY(event.getSceneY());
          
        } else {
          if(event.getClickCount()==1) {
            System.out.print(" centerX: " + circle.getCenterX());
            System.out.print(" centerY: " + circle.getCenterY());              
          }
          transition.setToX(event.getSceneX() - circle.getCenterX());
          transition.setToY(event.getSceneY() - circle.getCenterY());
          System.out.println();
          System.out.print("sceneX: " + event.getSceneX());
          System.out.print(" centerX: " + circle.getCenterX());
          System.out.print(" sceneX - centerX: " + (event.getSceneX() - circle.getCenterX()));
          System.out.println();
          System.out.print("sceneY: " + event.getSceneY());
          System.out.print(" centerY: " + circle.getCenterY());
          System.out.print(" sceneY - centerY: " + (event.getSceneY() - circle.getCenterY()));
          transition.playFromStart();
        }  
      }
    });
  }
}